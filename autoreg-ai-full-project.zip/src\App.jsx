import { useEffect, useState } from 'react';

const starterProfile = {
  fullName: 'Jayasurya K', email: 'user@email.com', mobile: '+91 9876543210', dob: '14/08/2003',
  gender: 'Male', address: '12, Anna Nagar, Chennai, Tamil Nadu 600040', qualification: 'B.Tech IT',
  college: 'ABC College', skills: 'Python, React, SQL, AI', experience: '1 year',
  emergency: 'Karthik K - +91 9876000001', additional: 'Interested in hackathons, full-stack development, and AI automation projects.',
};

const mappedFields = [
  ['Name', 'fullName'], ['Email', 'email'], ['Mobile', 'mobile'], ['Date of Birth', 'dob'],
  ['Gender', 'gender'], ['Address', 'address'], ['College / Company', 'college'],
  ['Qualification', 'qualification'], ['Skills', 'skills'],
];

const initialHistory = [
  { title: 'Hackathon 2026', status: 'Completed', date: '26 Sep 2026' },
  { title: 'Campus Fellowship', status: 'Saved', date: '22 Sep 2026' },
];

function App() {
  const [page, setPage] = useState('dashboard');
  const [profile, setProfile] = useState(() => {
    try { return { ...starterProfile, ...JSON.parse(localStorage.getItem('autoreg-profile') || '{}') }; } catch { return starterProfile; }
  });
  const [request, setRequest] = useState('I want to register for a college hackathon.');
  const [sourceUrl, setSourceUrl] = useState('');
  const [sourceFile, setSourceFile] = useState(null);
  const [draft, setDraft] = useState(null);
  const [processingStep, setProcessingStep] = useState(0);
  const [reviewed, setReviewed] = useState(false);
  const [authorized, setAuthorized] = useState(false);
  const [notice, setNotice] = useState('');
  const [serviceStatus, setServiceStatus] = useState('checking');
  const [aiIssues, setAiIssues] = useState([]);
  const [chatAnswer, setChatAnswer] = useState('');
  const [validating, setValidating] = useState(false);
  const [history, setHistory] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('autoreg-history') || 'null');
      return saved?.length ? saved : initialHistory;
    } catch { return initialHistory; }
  });

  useEffect(() => { localStorage.setItem('autoreg-profile', JSON.stringify(profile)); }, [profile]);
  useEffect(() => { localStorage.setItem('autoreg-history', JSON.stringify(history)); }, [history]);
  useEffect(() => {
    fetch('/api/health')
      .then((response) => response.ok ? response.json() : Promise.reject(new Error('API unavailable')))
      .then((health) => setServiceStatus(health.gemini_configured ? 'gemini' : 'backend'))
      .catch(() => setServiceStatus('offline'));
    fetch('/api/profile')
      .then((response) => response.ok ? response.json() : null)
      .then((result) => {
        if (result?.profile && Object.keys(result.profile).length) {
          setProfile((current) => ({ ...current, fullName: result.profile.name || current.fullName, email: result.profile.email || current.email, mobile: result.profile.phone || current.mobile, college: result.profile.college || current.college }));
        }
      }).catch(() => {});
    fetch('/api/history')
      .then((response) => response.ok ? response.json() : null)
      .then((result) => {
        if (result?.items?.length) setHistory(result.items.map((item) => ({ title: item.form_title, status: item.status, date: new Date(item.created_at).toLocaleDateString() })));
      }).catch(() => {});
  }, []);

  const go = (next) => { setPage(next); setNotice(''); };
  const apiProfile = { name: profile.fullName, email: profile.email, phone: profile.mobile, college: profile.college };
  const saveProfile = async (event) => {
    event.preventDefault();
    localStorage.setItem('autoreg-profile', JSON.stringify(profile));
    try {
      const response = await fetch('/api/profile', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ profile: apiProfile }) });
      if (!response.ok) throw new Error('Profile service unavailable');
      setNotice('Profile saved to the local database and ready to reuse.');
    } catch { setNotice('Profile saved on this device. Start FastAPI to sync it to SQLite.'); }
    go('request');
  };
  const runLocalDraft = () => mappedFields.map(([label, key]) => ({ label, key, value: profile[key] || '', required: ['Name', 'Email', 'Mobile', 'College / Company'].includes(label) }));
  const generateRegistration = async (event) => {
    event.preventDefault();
    if (!request.trim() && !sourceUrl && !sourceFile) { setNotice('Add a link, upload a form, or describe the registration first.'); return; }
    setProcessingStep(0); go('processing');
    let step = 0;
    const timer = setInterval(() => {
      step += 1;
      setProcessingStep(step);
      if (step === 4) {
        clearInterval(timer);
        prepareDraft().then(() => setTimeout(() => go('generated'), 500));
      }
    }, 650);
  };
  const prepareDraft = async () => {
    try {
      let response;
      if (sourceFile) {
        const formData = new FormData();
        formData.append('file', sourceFile);
        formData.append('prompt', request || 'Extract the registration fields from this document.');
        formData.append('profile', JSON.stringify(apiProfile));
        response = await fetch('/api/forms/scan', { method: 'POST', body: formData });
      } else {
        response = await fetch('/api/forms/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ request: `${request}\nRegistration link: ${sourceUrl || 'none'}`, profile: apiProfile }) });
      }
      const result = await response.json();
      if (!response.ok) throw new Error(result.detail || 'AI service unavailable');
      const generated = result.fields.map((field) => ({ label: field.label, key: field.id, value: field.value || '', required: field.required }));
      setDraft(generated);
      setAiIssues([]);
      setServiceStatus('gemini');
      setNotice('Gemini prepared this registration. Review every field before continuing.');
    } catch {
      setServiceStatus((current) => current === 'checking' ? 'offline' : current);
      setDraft(runLocalDraft());
      setAiIssues([]);
      setNotice('Demo draft generated locally. Connect FastAPI with GEMINI_API_KEY for live AI mapping.');
    }
  };
  const updateDraft = (key, value) => setDraft((current) => current.map((field) => field.key === key ? { ...field, value } : field));
  const validateDraft = async () => {
    if (!draft) return;
    setValidating(true);
    try {
      const response = await fetch('/api/forms/validate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fields: draft.map((field) => ({ id: field.key, label: field.label, type: 'text', required: field.required, value: field.value })) }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.detail || 'Validation unavailable');
      setAiIssues(result.issues || []);
      setNotice(result.issues?.length ? `Gemini found ${result.issues.length} item${result.issues.length === 1 ? '' : 's'} to review.` : 'Gemini validation found no clear issues.');
      setServiceStatus('gemini');
    } catch {
      const issues = [];
      if (draft.some((field) => field.required && !field.value.trim())) issues.push({ field_id: 'required', message: 'Complete every required field.' });
      const email = draft.find((field) => field.key === 'email');
      if (email?.value && !/^\S+@\S+\.\S+$/.test(email.value)) issues.push({ field_id: 'email', message: 'Enter a valid email address.' });
      setAiIssues(issues);
      setNotice('Local validation completed. Connect Gemini for deeper checks.');
    } finally { setValidating(false); }
  };
  const askAssistant = async (event) => {
    event.preventDefault();
    const missing = draft?.find((field) => field.required && !field.value.trim());
    if (!missing || !chatAnswer.trim()) return;
    let answer = chatAnswer.trim();
    try {
      const response = await fetch('/api/forms/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ form_title: 'Hackathon 2026 Registration', field_label: missing.label, value: answer }) });
      const result = await response.json();
      if (response.ok) answer = result.value || answer;
    } catch { /* Local answer is still useful when Gemini is offline. */ }
    updateDraft(missing.key, answer);
    setChatAnswer('');
    setNotice(`${missing.label} added to your draft.`);
  };
  const submitRegistration = async () => {
    const localEntry = { title: 'Hackathon 2026', status: 'Completed', date: '26 Sep 2026' };
    setHistory((current) => [localEntry, ...current]);
    try {
      const response = await fetch('/api/history', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ form_title: 'Hackathon 2026', request, fields: draft.map((field) => ({ id: field.key, label: field.label, type: 'text', required: field.required, value: field.value })) }) });
      if (!response.ok) throw new Error('History service unavailable');
      setNotice('Registration approved and saved to SQLite.');
    } catch { setNotice('Registration approved and saved in this browser.'); }
    go('success');
  };

  const navItems = [
    ['dashboard', 'Dashboard'], ['profile', 'My Profile'], ['request', 'New Registration'], ['history', 'Registration History'],
    ['saved', 'Saved Forms'], ['privacy', 'Privacy & Security'], ['settings', 'Settings'],
  ];

  return <div className="app-shell">
    <aside className="sidebar">
      <button className="brand" onClick={() => go('dashboard')}><span className="brand-mark">A</span><span><strong>AutoReg AI</strong><small>Universal registration assistant</small></span></button>
      <div className="workspace-label">WORKSPACE</div>
      <nav className="side-nav" aria-label="Main navigation">{navItems.map(([id, label]) => <button key={id} className={`nav-item ${page === id ? 'active' : ''}`} onClick={() => go(id)}><span className="nav-icon">{id === 'dashboard' ? '⌂' : id === 'request' ? '+' : id === 'profile' ? '○' : id === 'history' ? '↗' : id === 'privacy' ? '◇' : '□'}</span>{label}</button>)}</nav>
      <div className="sidebar-bottom"><div className="backend-status"><span className="status-dot connected" /><span><strong>Demo workspace</strong><small>Profile saved locally</small></span></div><button className="profile-mini" onClick={() => go('profile')}><span className="avatar">{profile.fullName.charAt(0)}</span><span><strong>{profile.fullName}</strong><small>Personal profile</small></span></button></div>
    </aside>

    <main className="main-content">
      <header className="topbar"><div className="breadcrumb"><span>Workspace</span><span>/</span><strong>{page === 'dashboard' ? 'Dashboard' : page.replace('-', ' ')}</strong></div><span className="secure-note">◇ Your data stays yours</span></header>
      {notice && <div className="notice" role="status"><span>i</span>{notice}<button onClick={() => setNotice('')}>×</button></div>}
      {page === 'dashboard' && <Dashboard go={go} history={history} profile={profile} />}
      {page === 'profile' && <Profile profile={profile} setProfile={setProfile} saveProfile={saveProfile} />}
      {page === 'request' && <Request request={request} setRequest={setRequest} sourceUrl={sourceUrl} setSourceUrl={setSourceUrl} sourceFile={sourceFile} setSourceFile={setSourceFile} generate={generateRegistration} />}
      {page === 'processing' && <Processing activeStep={processingStep} />}
      {page === 'generated' && draft && <Generated draft={draft} updateDraft={updateDraft} go={go} request={request} aiIssues={aiIssues} validateDraft={validateDraft} validating={validating} chatAnswer={chatAnswer} setChatAnswer={setChatAnswer} askAssistant={askAssistant} />}
      {page === 'confirmation' && <Confirmation reviewed={reviewed} authorized={authorized} setReviewed={setReviewed} setAuthorized={setAuthorized} submit={submitRegistration} />}
      {page === 'success' && <Success go={go} />}
      {page === 'history' && <History history={history} go={go} />}
      {page === 'saved' && <EmptyPage title="Saved Forms" copy="Your reusable registration templates will appear here." action="Start a registration" onClick={() => go('request')} />}
      {page === 'privacy' && <Privacy />}
      {page === 'settings' && <EmptyPage title="Settings" copy="Personalize your AutoReg AI workspace and notification preferences." action="Edit my profile" onClick={() => go('profile')} />}
    </main>
  </div>;
}

function PageHeading({ eyebrow, title, copy }) { return <section className="page-heading"><div><div className="eyebrow">{eyebrow} <span className="eyebrow-line" /></div><h1>{title}</h1><p>{copy}</p></div></section>; }
function Dashboard({ go, history, profile }) { return <div className="workspace-page dashboard-page"><PageHeading eyebrow="YOUR WORKSPACE" title={`Hello, ${profile.fullName.split(' ')[0]} 👋`} copy="Your personal registration command center." /><div className="dashboard-hero"><div><span className="eyebrow">AUTOREG AI</span><h2>Ready to make registration feel automatic?</h2><p>Use your saved profile to prepare a new registration in minutes.</p></div><button className="primary-btn" onClick={() => go('request')}>+ New Registration</button></div><div className="dashboard-grid"><button onClick={() => go('profile')}><strong>My Profile</strong><span>Manage reusable personal details</span><b>→</b></button><button onClick={() => go('history')}><strong>Registration History</strong><span>{history.length} saved registration drafts</span><b>→</b></button><button onClick={() => go('saved')}><strong>Saved Forms</strong><span>Reusable form templates</span><b>→</b></button><button onClick={() => go('privacy')}><strong>Privacy & Security</strong><span>Consent and data controls</span><b>→</b></button></div><div className="dashboard-stats"><div><span>Registrations</span><strong>24</strong><small>↑ 18% this month</small></div><div><span>Completed</span><strong>18</strong><small>75% completion rate</small></div><div><span>Time saved</span><strong>4.8h</strong><small>↑ 2.1h this month</small></div></div></div>; }
function Profile({ profile, setProfile, saveProfile }) { const fields = [['fullName', 'Full Name'], ['email', 'Email'], ['mobile', 'Mobile Number'], ['dob', 'Date of Birth'], ['gender', 'Gender'], ['address', 'Address'], ['qualification', 'Qualification'], ['college', 'College / Company'], ['skills', 'Skills'], ['experience', 'Experience'], ['emergency', 'Emergency Contact'], ['additional', 'Additional Information']]; return <section className="workspace-page secondary-page"><PageHeading eyebrow="USER INPUT" title="Your profile, once." copy="Save the details you use most. AutoReg AI will match them to future registrations." /><form className="profile-editor" onSubmit={saveProfile}><div className="profile-editor-heading"><div><span className="form-overline">PERSONAL DETAILS</span><h2>Saved information</h2></div><span className="private-label">◇ Stored on this device</span></div><div className="profile-fields">{fields.map(([key, label]) => <div className={`form-field ${['address', 'skills', 'additional'].includes(key) ? 'wide' : ''}`} key={key}><label htmlFor={`profile-${key}`}>{label}</label>{['address', 'additional'].includes(key) ? <textarea id={`profile-${key}`} rows="2" value={profile[key]} onChange={(event) => setProfile({ ...profile, [key]: event.target.value })} /> : <input id={`profile-${key}`} value={profile[key]} onChange={(event) => setProfile({ ...profile, [key]: event.target.value })} />}</div>)}</div><div className="profile-save-row"><p>One secure profile powers every supported registration.</p><button className="primary-btn" type="submit">Save My Profile <span>✓</span></button></div></form></section>; }
function Request({ request, setRequest, sourceUrl, setSourceUrl, sourceFile, setSourceFile, generate }) { return <section className="workspace-page flow-page"><PageHeading eyebrow="REGISTRATION REQUEST" title="What do you want to register for?" copy="Give AutoReg AI a link, a form, or a plain-language description." /><div className="request-options"><form className="request-card" onSubmit={generate}><span className="option-number">01</span><h2>Describe the registration</h2><textarea value={request} onChange={(event) => setRequest(event.target.value)} placeholder="I want to register for a college hackathon." rows="4" /><button className="primary-btn" type="submit">Generate Registration <span>↗</span></button></form><div className="request-card"><span className="option-number">02</span><h2>Paste a registration link</h2><input type="url" value={sourceUrl} onChange={(event) => setSourceUrl(event.target.value)} placeholder="https://example.com/register" /><p>AI reads supported registration pages and identifies the fields you need.</p></div><label className="request-card upload-card"><span className="option-number">03</span><h2>Upload a form</h2><div className="upload-placeholder">📄<br /><strong>PDF, image, or document</strong><small>Choose a file to scan with AI</small></div><input type="file" accept=".pdf,image/*,.doc,.docx" onChange={(event) => setSourceFile(event.target.files?.[0] || null)} />{sourceFile && <span className="file-chip">{sourceFile.name}</span>}</label></div><div className="source-note">✳ AI combines your profile, the registration source, and the purpose you describe before generating a draft.</div></section>; }
function Processing({ activeStep }) { const labels = ['Analyzing Registration Form', 'Detecting Fields', 'Matching Your Information', 'Validating Data', 'Registration Form Ready']; return <section className="workspace-page processing-page"><PageHeading eyebrow="AI PROCESSING" title="Preparing your registration." copy="AutoReg AI is understanding the source and matching it to your profile." /><div className="processing-card"><div className="loader" /><div className="processing-lines">{labels.map((label, index) => <div className={index <= activeStep ? 'active' : ''} key={label}><span>{index < activeStep ? '✓' : index === activeStep ? '●' : '○'}</span>{label}{index === activeStep && index < 4 ? '...' : ''}</div>)}</div></div></section>; }
function Generated({ draft, updateDraft, go, request, aiIssues, validateDraft, validating, chatAnswer, setChatAnswer, askAssistant }) {
  const missing = draft.filter((field) => field.required && !field.value.trim());
  const blocked = missing.length > 0 || aiIssues.length > 0;
  return <section className="workspace-page flow-page"><PageHeading eyebrow="GENERATED REGISTRATION" title="Your registration is ready to review." copy="AI detected the fields, matched your profile, and validated the draft. Edit anything before confirming." /><div className="generated-layout"><div className="generated-form"><div className="generated-form-header"><div><span className="form-overline">AI-PREPARED FORM</span><h2>Hackathon 2026 Registration</h2></div><span className="match-pill">99% MATCH</span></div><div className="field-list">{draft.map((field) => <div className="form-field" key={field.key}><label>{field.label}{field.required && <span className="required-mark"> *</span>}</label><input value={field.value} onChange={(event) => updateDraft(field.key, event.target.value)} /><span className={field.value ? 'match-indicator' : 'missing-indicator'}>{field.value ? '✓ Matched from your profile' : 'Required to complete'}</span></div>)}</div><div className="validation-bar"><span className={blocked ? 'validation-warning' : 'validation-good'}>{blocked ? `${missing.length + aiIssues.length} item${missing.length + aiIssues.length === 1 ? '' : 's'} to check` : 'Everything looks good'}</span><button className="ai-validate-btn" onClick={validateDraft} disabled={validating}>{validating ? 'Checking with Gemini...' : '✳ Run AI validation'}</button></div>{aiIssues.length > 0 && <ul className="ai-issues">{aiIssues.map((issue, index) => <li key={`${issue.field_id}-${index}`}>{issue.message}</li>)}</ul>}<div className="generated-actions"><button className="secondary-btn" onClick={() => go('profile')}>Edit profile</button><button className="primary-btn" disabled={blocked} onClick={() => go('confirmation')}>Confirm <span>→</span></button></div></div><aside className="ai-explain"><span className="rail-mark">✳</span><h3>AI registration assistant</h3><p>Understood “{request || 'registration request'}” and mapped the form by meaning, not just exact labels.</p><div className="ai-check">✓ Detected registration fields</div><div className="ai-check">✓ Matched similar labels</div><div className="ai-check">✓ Checked required information</div>{missing.length > 0 && <form className="chat-form" onSubmit={askAssistant}><label>I still need your {missing[0].label.toLowerCase()}</label><div className="chat-input-row"><input value={chatAnswer} onChange={(event) => setChatAnswer(event.target.value)} placeholder={`Your ${missing[0].label.toLowerCase()}`} /><button type="submit" disabled={!chatAnswer.trim()}>↑</button></div><small>Your answer fills the matching field above.</small></form>}<div className="extension-note">◇ After approval, the AutoReg AI browser extension can fill supported visible fields. It never submits the website.</div></aside></div></section>;
}
function Confirmation({ reviewed, authorized, setReviewed, setAuthorized, submit }) { return <section className="workspace-page flow-page narrow-page"><PageHeading eyebrow="FINAL CONFIRMATION" title="Your registration is ready." copy="Nothing is submitted without your approval." /><div className="confirmation-card"><div className="success-mark">✓</div><h2>Review and authorize</h2><p>AutoReg AI has prepared Hackathon 2026 Registration using your saved profile.</p><label className="approval-check"><input type="checkbox" checked={reviewed} onChange={(event) => setReviewed(event.target.checked)} /><span>I have reviewed my information.</span></label><label className="approval-check"><input type="checkbox" checked={authorized} onChange={(event) => setAuthorized(event.target.checked)} /><span>I authorize AutoReg AI to use this information for this registration.</span></label><button className="primary-btn full" disabled={!reviewed || !authorized} onClick={submit}>Submit Registration <span>→</span></button><small className="approval-footnote">The user remains in control. Submission only happens after both approvals are selected.</small></div></section>; }
function Success({ go }) { return <section className="workspace-page success-page"><div className="success-card"><div className="success-mark">✓</div><div className="eyebrow">REGISTRATION COMPLETE</div><h1>Registration Completed!</h1><p>Registration: Hackathon 2026<br />Date: 26 Sep 2026</p><div className="reference">Reference ID: AR-2026-XXXXX</div><div className="cta-row"><button className="primary-btn" onClick={() => {}}>View Registration</button><button className="secondary-btn" onClick={() => go('dashboard')}>Back to Dashboard</button></div></div></section>; }
function History({ history, go }) { return <section className="workspace-page secondary-page"><PageHeading eyebrow="YOUR WORKSPACE" title="Registration history" copy="Every approved registration draft, in one place." /><div className="history-list">{history.map((item, index) => <article className="history-row" key={`${item.title}-${index}`}><div><span className="history-date">{item.date}</span><h2>{item.title}</h2><p>Prepared with AutoReg AI and approved by you.</p></div><span className="history-status">{item.status}</span></article>)}</div><button className="primary-btn" onClick={() => go('request')}>Start a registration <span>→</span></button></section>; }
function Privacy() { return <section className="workspace-page secondary-page"><PageHeading eyebrow="YOUR CONTROL" title="Privacy & Security" copy="You decide what AutoReg AI can use and when it can act." /><div className="privacy-box"><label className="privacy-item"><span>Require approval before submission</span><input type="checkbox" defaultChecked /></label><label className="privacy-item"><span>Keep profile stored on this device</span><input type="checkbox" defaultChecked /></label><div className="privacy-item"><span>Export my profile data</span><button className="secondary-btn small">Export</button></div><div className="privacy-item"><span>Delete profile</span><button className="secondary-btn small danger">Delete</button></div></div></section>; }
function EmptyPage({ title, copy, action, onClick }) { return <section className="workspace-page empty-page"><PageHeading eyebrow="WORKSPACE" title={title} copy={copy} /><div className="empty-activity"><span className="empty-icon">□</span><h2>Nothing here yet</h2><p>Build your first reusable AutoReg AI asset.</p><button className="primary-btn" onClick={onClick}>{action} <span>→</span></button></div></section>; }

export default App;
